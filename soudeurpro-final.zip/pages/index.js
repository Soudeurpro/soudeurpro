export default function Home() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>Bienvenue sur SoudeurPro</h1>
      <p>Plateforme de mise en relation entre recruteurs et soudeurs.</p>
    </div>
  );
}
